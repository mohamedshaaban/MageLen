
 var config = {
    "waitSeconds": 0,
    "map": {
        "*": {}
    },
    "shim":{

    },
    deps:[
        'Vsourz_Ordercomment/js/ordercomment'
    ]
};
