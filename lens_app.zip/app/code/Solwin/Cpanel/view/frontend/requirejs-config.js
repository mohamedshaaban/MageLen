var config = {
    map: {
        '*': {
            cpowlcarousel: 'Solwin_Cpanel/js/owl.carousel',
        }
    },
    deps: [
        "js/animation68b3"
    ]
};